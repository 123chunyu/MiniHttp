#**0.socket简介**#
===========================

    socket编程也叫套接字编程,应用程序可以通过它发送或者接受数据,可对其像打开文件一样打开/关闭/读写等操作.
    套接字允许应用程序将I/O插入到网络中,并与网络中的其他应用程序进行通信.
    TCP协议中，socket=IP地址+port
    网络通信其实就是Socket之间的通信,数据在两个Socket之间通过I/O进行传输.
    ![TCP网络通信模型](TCP网路通信模型.png)

#**1.socket()**
======================
*Linux 中的一切都是文件，每个文件都有一个整数类型的文件描述符；socket 也是一个文件，也有文件描述符。socket 也是一个文件，也有文件描述符。*

    使用 socket() 函数创建套接字以后，返回值就是一个 int 类型的文件描述符。

    在 Linux 下使用 <sys/socket.h> 头文件中 socket() 函数来创建套接字，原型为：

*int socket(int af, int type, int protocol);*

    af 为地址族（Address Family），也就是 IP 地址类型，常用的有 AF_INET 和 AF_INET6。AF 是“Address Family”的简写，
    INET是“Inetnet”的简写。
    AF_INET 表示 IPv4 地址，例如 127.0.0.1；
    AF_INET6 表示 IPv6 地址，例如 1030::C9B4:FF12:48AA:1A2B。

#**2.bzero()**
========================
*void bzero（void *s, int n）;*

    用法：#include <string.h>
    功能：置字节字符串s的前n个字节为零且包括‘\0’。

#**3.listen()**
===========================
*listen(int sockfd, int backlog)函数用于服务器，使已绑定的socket等待监听客户端的连接请求，并设置服务器同时可连接的数量*

    listen函数位于sys/socket.h头文件中；
    sockfd为socket文件描述符；
    backlog用于设置请求队列最大长度；
    listen函数调用成功返回0，否则返回-1；


#**4.bind()**#
==================================
*bind(int sockfd,  const struct sockaddr, socklen_t addrlen)函数把一个本地协议地址赋予一个套接字。对于网际协议，协议地址是32位的IPv4地址或是128位的IPv6地址与16位的TCP或UDP端口号的组合*

    #include<sys/socket.h>
    第二个参数是一个指向特定协议的地址结构的指针，第三个参数是该地址结构的长度。对于TCP，调用bind函数可以指定一个端口号，或指定一个IP地址，也可以两者都指定，还可以都不指定。


#**5.write() read()**
======================================
*write (int fd, const void * buf, size_t count)会把参数buf所指的内存写入count个字节到参数放到所指的文件内*
     
    如果顺利write()会返回实际写入的字节数。当有错误发生时则返回-1，错误代码存入errno中。

*read(int fd, void * buf, size_t count)会把参数fd所指的文件传送count 个字节到buf 指针所指的内存中*

    返回值为实际读取到的字节数, 如果返回0, 表示已到达文件尾或是无可读取的数据。若参数count 为0, 则read()不会有作用并返回0。



#**stat()**#
========================================================

    作用：返回文件的状态信息
    #include <sys/types.h>
    #include <sys/stat.h>
    #include <unistd.h>

    int stat(const char *path, struct stat *buf);
    int fstat(int fd, struct stat *buf);
    int lstat(const char *path, struct stat *buf);

path:
	文件的路径
buf:
	传入的保存文件状态的指针，用于保存文件的状态
返回值：
	成功返回0，失败返回-1，设置errno

        struct stat 
        {
            dev_t     st_dev;       /* ID of device containing file */
            ino_t     st_ino;       /* inode number */
            mode_t    st_mode;      /* S_ISREG(st_mode)  是一个普通文
                                        S_ISDIR(st_mode)  是一个目录*/
               
            nlink_t   st_nlink;     /* number of hard links */
            uid_t     st_uid;       /* user ID of owner */
            gid_t     st_gid;       /* group ID of owner */
            dev_t     st_rdev;      /* device ID (if special file) */
            off_t     st_size;      /* total size, in bytes */
            blksize_t st_blksize;   /* blocksize for filesystem I/O */
            blkcnt_t  st_blocks;    /* number of 512B blocks allocated */
            time_t    st_atime;     /* time of last access */
            time_t    st_mtime;     /* time of last modification */
            time_t    st_ctime;     /* time of last status change */
        };





/*

    sockaddr在头文件#include <sys/socket.h>中定义，sockaddr的缺陷是：sa_data把目标地址和端口信息混在一起了

    sockaddr_in在头文件#include<netinet/in.h>或#include <arpa/inet.h>中定义，该结构体解决了sockaddr的缺陷，把port和addr 分开储存在两个变量中，如下：


    struct sockaddr_in
    {
        sa_family_t     sin_family;     //地址族（Address Family）
        uint16_t        sin_port;       //16位TCP/UDP端口号
        struct in_addr  sin_addr;       //32位IP地址
        char            sin_zero[8];    //不使用
    };

    struct in_addr
    {
        In_addr_t       s_addr;         //32位IPV4
    };

*/


#**pthread_create()**

*创建一个新线程，并行的执行任务。*

    #include <pthread.h>

*int pthread_create(pthread_t *thread, const pthread_attr_t *attr, void *(*start_routine) (void *), void *arg);*

	返回值：成功：0；	失败：错误号。

    参数：	
	    pthread_t：当前Linux中可理解为：typedef  unsigned long int  pthread_t;

    参数1：传出参数，保存系统为我们分配好的线程ID
	参数2：通常传NULL，表示使用线程默认属性。若想使用具体属性也可以修改该参数。
	参数3：函数指针，指向线程主函数(线程体)，该函数运行结束，则线程结束。
	参数4：线程主函数执行期间所使用的参数。

    在一个线程中调用pthread_create()创建新的线程后，当前线程从pthread_create()返回继续往下执行，而新的线程所执行的代码由我们传给pthread_create的函数指针start_routine决定。

    start_routine函数接收一个参数，是通过pthread_create的arg参数传递给它的，该参数的类型为void *，这个指针按什么类型解释由调用者自己定义。
    start_routine的返回值类型也是void *，这个指针的含义同样由调用自己定义。
    start_routine返回时，这个线程就退出了，其它线程可以调用pthread_join得到start_routine的返回值，以后再详细介绍pthread_join。

    pthread_create成功返回后，新创建的线程的id被填写到thread参数所指向的内存单元。

    attr参数表示线程属性，本节不深入讨论线程属性，所有代码例子都传NULL给attr参数，表示线程属性取缺省值。




#**图片**#
![基本TCP客户/服务器程序的套接字函数](%E5%A5%97%E6%8E%A5%E5%AD%97%E5%87%BD%E6%95%B0.png)
![TCP网络通信模型](TCP网路通信模型.png)
![客户端请求报文格式](客户端请求报文格式.png)
![服务端响应报文格式](服务端响应报文格式.png)


#**表格**#

*1.服务器响应代号*

	响应代号	                               代号             描述
    服务器上存在请求的内容，并可以响应给客户端	  200	            OK
    客户端的请求有异常，方法有问题	             501 	   Method NotImplemented
    服务器收到请求后，因为自生的问题没法响应	  500	    Internal Server Error
    请求的内容不存在	                        404	         404 NOT FOUND
    客户端发送的请求格式有问题等	             400 	        BAD REQUEST